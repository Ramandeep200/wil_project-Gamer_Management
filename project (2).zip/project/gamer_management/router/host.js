const express = require("express");
const router = express.Router();
const { User } = require("../models/User");
const { verifyHost } = require("../auth/auth");


module.exports = router;
