 export const BaseUrl = 'http://192.168.0.141:3000';
// export const BaseUrl = 'http://localhost:5200';
//export const BaseUrl = 'https://pritam-node16.herokuapp.com';

// change this url accrodingly your backend link
// first start your backend then you will get a url that will be putted on this 
// start your termial and give a command npm i or yarn to install all pakages 
// after install you will get a url that will be putted on this and just give a command to termial yarn start or npm start